package com.company.SERVER.model;

public class User {

    private static int lastAssignedId;
    private int id;
    private String login;

    public User(String login) {
        lastAssignedId++;
        this.id = lastAssignedId;
        this.login = login;
    }

    public int getId() {
        return this.id;
    }

    public String getLogin() {
        return this.login;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", login='" + login + '\'' +
                '}';
    }
}
