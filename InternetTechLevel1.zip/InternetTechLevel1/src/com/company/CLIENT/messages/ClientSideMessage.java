package com.company.CLIENT.messages;

public class ClientSideMessage {

    enum Type {
        PING,
        LOGIN,
        QUIT,
        CRITICAL_ERROR,
        SOFT_ERROR,
        MESSAGE,
        YOUR_BROADCAST,
        OTHERS_BROADCAST,
        HELO,
        GET_USERS,
        CREATE_GROUP,
        GET_GROUPS,
        JOIN_GROUP,
        GROUP_MESSAGE,
        LEAVE_GROUP,
        SUCCESS,
        KICK,
        PM
    }

    public enum Sender {
        CLIENT,
        SERVER
    }

    private Sender sender;

    private Type type;
    private String message;

    public ClientSideMessage(String line, Sender sender) {
        this.sender = sender;
        init(line);

    }

    private void init(String line) {

        if (this.sender == Sender.SERVER) {

            if (line.equals("PING")) {
                this.type = Type.PING;
                this.message = "PONG";
            } else if (line.startsWith("-ERR")) {
                this.type = Type.CRITICAL_ERROR;
                this.message = line.replace("-ERR ", "").trim();
            } else if (line.startsWith("HELO Welkom")) {
                this.type = Type.LOGIN;
                this.message = "HI! You've been connected!\nPlease enter your login:";
            } else if (line.startsWith("+OK HELO")) {
                this.type = Type.HELO;
                this.message = "Welcome! You can now write your messages!";
            } else if (line.startsWith("+OK BCST")) {
                this.type = Type.YOUR_BROADCAST;
                this.message = line.replace("+OK BCST", "".trim());
            } else if (line.startsWith("BCST [")) {
                this.type = Type.OTHERS_BROADCAST;
                this.message = line.replace("BCST ", "").trim();
            } else if (line.equals("+OK Goodbye")) {
                this.type = Type.QUIT;
                this.message = "Goodbye!";
            } else if (line.startsWith("PM [")) {
                this.type = Type.PM;
                this.message = line.replace("PM ", "");
            } else if (line.startsWith("-SOFT_ERR")) {
                this.type = Type.SOFT_ERROR;
                this.message = line.replace("-SOFT_ERR ", "");
            } else if (line.startsWith("GROUP_MESSAGE [")) {
                this.type = Type.GROUP_MESSAGE;
                this.message = line.replace("GROUP_MESSAGE ", "");
            } else if (line.startsWith("+SUCCESS")) {
                this.type = Type.SUCCESS;
                this.message = line.replace("+SUCCESS ", "");
            }
        } else {
            if (line.equals("q".trim())) {
                this.type = Type.QUIT;
                this.message = "QUIT";

            } else if (line.equals("*all".trim())) {
                this.type = Type.GET_USERS;
                this.message = "GET_USERS " + line;

            } else if (line.matches("\\s*@[a-zA-Z0-9_]+\\s.+")) {
                this.type = Type.PM;
                this.message = "PM " + line;

            } else if (line.matches("/create_group\\s\\S+")) {
                this.type = Type.CREATE_GROUP;
                this.message = "CREATE_GROUP " + line.replace("/create_group ", "");

            } else if (line.equals("*groups".trim())) {
                this.type = Type.GET_GROUPS;
                this.message = "GET_GROUPS " + line;
            } else if (line.matches("/join\\s\\S+")) {
                this.type = Type.JOIN_GROUP;
                this.message = "JOIN_GROUP " + line.replace("/join ", "");
            } else if (line.matches("\\s*@@\\S+\\s\\S+")) {
                this.type = Type.GROUP_MESSAGE;
                this.message = "GROUP_MESSAGE " + line;
            } else if (line.matches("/leave\\s\\S+")) {
                this.type = Type.LEAVE_GROUP;
                this.message = "LEAVE_GROUP " + line.replace("/leave ", "");
            } else if (line.matches("/kick\\s\\S+\\s\\S+")) {
                this.type = Type.KICK;
                this.message = "KICK " + line.replace("/kick ", "");
            } else {
                this.type = Type.MESSAGE;
                this.message = line;
            }
        }
    }

    public Type getType() {
        return type;
    }

    public String getMessage() {
        return message;
    }

    public Sender getSender() {
        return sender;
    }
}
