package com.company.CLIENT;

public class ClientMain {

    public static void main(String[] args) {

        new ClientMain().run();
    }

    private void run() {

        Client client = new Client();
        client.run();
    }
}
