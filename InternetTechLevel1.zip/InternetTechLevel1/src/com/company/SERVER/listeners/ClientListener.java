package com.company.SERVER.listeners;

import com.company.SERVER.ChatManager;
import com.company.SERVER.messages.ServerSideMessage;
import com.company.SERVER.messages.ServerSideMessageInterpreter;

import java.io.*;
import java.net.Socket;

public class ClientListener implements Runnable {

    private BufferedReader reader;
    private PrintWriter printWriter;

    private ServerSideMessageInterpreter interpreter;

    public ClientListener(Socket socket,
                          ServerSideMessageInterpreter interpreter) {
        this.interpreter = interpreter;

        try {
            this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            this.printWriter = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        String line = "";
        printWriter.println("HELO Welkom   ");
        while (!ChatManager.getUsers().isEmpty()) {
            try {
                line = reader.readLine();
//                System.out.println(line);
                ServerSideMessage message = new ServerSideMessage(line);

                interpreter.interprete(message);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
