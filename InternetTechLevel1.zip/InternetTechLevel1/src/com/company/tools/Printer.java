package com.company.tools;

public class Printer {


    public static final String ANSI_RESET = "\u001B[0m";            //Reset
    public static final String ANSI_RED = "\u001B[31m";             //Error messages
    public static final String ANSI_YELLOW = "\u001B[33m";          //OK messages
    public static final String ANSI_PURPLE = "\u001B[35m";          //Group message

    public static final String ANSI_CYAN = "\u001B[36m";            //Other's messages


    public static void printError(String message) {
        System.out.println(ANSI_RED + message + ANSI_RESET);
    }

    public static void printOthersMessage(String message) {
        System.out.println(ANSI_CYAN + message + ANSI_RESET);
    }

    public static void printOkMessage(String message) {
        System.out.println(ANSI_YELLOW + message + ANSI_RESET);
    }

    public static void printGroupMessage(String message) {
        System.out.println(ANSI_PURPLE + message + ANSI_RESET);
    }

}
