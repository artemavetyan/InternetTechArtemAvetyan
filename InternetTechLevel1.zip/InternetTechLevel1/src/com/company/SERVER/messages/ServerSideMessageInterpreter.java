package com.company.SERVER.messages;

import com.company.CLIENT.messages.ClientSideMessageInterpreter;
import com.company.SERVER.ChatManager;
import com.company.SERVER.model.Group;
import com.company.SERVER.model.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerSideMessageInterpreter {

    private Socket socket;
    private PrintWriter writer;

    public ServerSideMessageInterpreter(Socket socket) {
        try {
            this.writer = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.socket = socket;
    }

    public void interprete(ServerSideMessage message) {
        if (message.getType() == ServerSideMessage.Type.LOGIN) {
            if (!ChatManager.isUniqueLogin(message.getMessage())) {
                writer.println("-ERR user already logged in");
                try {
                    socket.close();
                    ChatManager.deleteUser(socket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                if (!ChatManager.isValidLogin(message.getMessage())) {
                    writer.println(
                            "-ERR username has an invalid format (only characters, numbers and underscores are allowed)");
                    try {
                        socket.close();
                        ChatManager.deleteUser(socket);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    ChatManager.addUser(message.getMessage(), socket);
                    writer.println("+OK HELO " + message.getMessage());
                }
            }
        } else if (message.getType() == ServerSideMessage.Type.QUIT) {
            writer.println(message.getMessage());
            ChatManager.deleteUser(socket);
        } else if (message.getType() == ServerSideMessage.Type.BROADCAST) {
            writer.println("+OK BCST " + message.getMessage());
            sendBroadcastMessage(message.getMessage());
        } else if (message.getType() == ServerSideMessage.Type.GET_USERS) {
            String response = ChatManager.getUsers().values().toString();
            writer.println("+SUCCESS " + response);
        } else if (message.getType() == ServerSideMessage.Type.PM) {
            String destinationLogin = ChatManager.retrieveLoginFromPrivateMessage(message.getMessage());
            Socket destinationSocket = ChatManager.findUserByLogin(destinationLogin);

            if (destinationSocket == null) {
                //no user found
                writer.println("-SOFT_ERR no such user!");
            } else {
                writer.println("+OK PM");
                PrintWriter destination = null;
                String sender = ChatManager.getUsers().get(socket).getLogin();
                try {
                    destination = new PrintWriter(destinationSocket.getOutputStream(), true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                destination.println(
                        "PM [" + sender + "] " + ChatManager.retrieveMessageFromPrivateMessage(message.getMessage()));
                //send pm
            }
        } else if (message.getType() == ServerSideMessage.Type.CREATE_GROUP) {
            String groupName = message.getMessage();
            if (ChatManager.findGroupByName(groupName) != null) {
                writer.println("-SOFT_ERR a group with that name already exists!");
            } else {
                String admin = ChatManager.getUsers().get(socket).getLogin();
                ChatManager.addGroup(admin, groupName);
                writer.println("+SUCCESS group \"" + groupName + "\" has been created!");
            }
        } else if (message.getType() == ServerSideMessage.Type.GET_GROUPS) {
            if (ChatManager.getGroups().isEmpty()) {
                writer.println("-SOFT_ERR there are no groups yet");
            } else {
                String response = ChatManager.getGroups().toString();
                writer.println("+SUCCESS " + response);
            }
        } else if (message.getType() == ServerSideMessage.Type.JOIN_GROUP) {
            Group group = ChatManager.findGroupByName(message.getMessage());
            if (group == null) {
                writer.println("-SOFT_ERR no such group!");
            } else {
                String sender = ChatManager.getUsers().get(socket).getLogin();
                if (group.getMembers().contains(sender) || group.getAdmin().equals(sender)) {
                    writer.println("-SOFT_ERR you are already a member of that group!");
                } else if (group.getBanned().contains(sender)) {
                    writer.println("-SOFT_ERR you are banned from that group!");
                } else {
                    group.addMember(sender);
                    writer.println("+SUCCESS you have successfully entered group " + group.getGroupName());
                }
            }
        } else if (message.getType() == ServerSideMessage.Type.GROUP_MESSAGE) {
            String groupName = ChatManager.retrieveGroupNameFromMessage(message.getMessage());
            Group group = ChatManager.findGroupByName(groupName);
            if (group == null) {
                writer.println("-SOFT_ERR no such group!");
            } else {
                String sender = ChatManager.getUsers().get(socket).getLogin();
                if (!group.getMembers().contains(sender) && !group.getAdmin().equals(sender)) {
                    writer.println("-SOFT_ERR you are not allowed to write in that group!");
                } else {
                    String groupMessage = ChatManager.retrieveMessageFromGroupMessage(message.getMessage());
                    sendGroupMessage(group, groupMessage);
                }
            }

        } else if (message.getType() == ServerSideMessage.Type.LEAVE_GROUP) {
            String groupName = message.getMessage();
            Group group = ChatManager.findGroupByName(groupName);
            if (group == null) {
                writer.println("-SOFT_ERR no such group!");
            } else {
                String sender = ChatManager.getUsers().get(socket).getLogin();
                if (!group.getMembers().contains(sender) && !group.getAdmin().equals(sender)) {
                    writer.println("-SOFT_ERR you are not a member of that group!");
                } else {
                    group.removeMember(sender);
                    writer.println("+SUCCESS you have successfully left the group \"" + groupName + "\" !");
                }
            }
        } else if (message.getType() == ServerSideMessage.Type.KICK) {
            String groupName = ChatManager.retrieveGroupNameFromKickMessage(message.getMessage());
            Group group = ChatManager.findGroupByName(groupName);
            if (group == null) {
                writer.println("-SOFT_ERR no such group!");
            } else {
                String sender = ChatManager.getUsers().get(socket).getLogin();
                if (!group.getAdmin().equals(sender)) {
                    writer.println("-SOFT_ERR you are not allowed to kick members out that group!");
                } else {
                    String memberToKick = message.getMessage().replace(groupName, "").trim();
                    if (!group.getMembers().contains(memberToKick)) {
                        writer.println(
                                "-SOFT_ERR user \"" + memberToKick + "\" is not a member of group \"" + groupName +
                                        "\" !");

                    }
//                    else if (group.getAdmin().equals(sender)) {
//                        writer.println(
//                                "-SOFT_ERR why would you kick yourself out of your group :)?");
//                    }
                    else {
                        group.kickMember(memberToKick);
                        sendGroupMessage(group,
                                "user \"" + memberToKick + "\" has been kicked out of group \"" + groupName +
                                        "\"");
                        writer.println(
                                "+SUCCESS user \"" + memberToKick + "\" has been kicked out of group \"" + groupName +
                                        "\"");
                        Socket kickedUser = ChatManager.findUserByLogin(memberToKick);
                        PrintWriter kickedUserWriter = null;
                        try {
                            kickedUserWriter = new PrintWriter(kickedUser.getOutputStream(), true);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        kickedUserWriter.println("+SUCCESS you have been kicked out of the group \"" + groupName +
                                "\""); //you have been kicked out of group
                    }
                }
            }
        } else if (message.getType() == ServerSideMessage.Type.PONG) {
            if ( ChatManager.getUsers().get(socket) != null) {
                System.out.println(message.getMessage() + ChatManager.getUsers().get(socket).getLogin());
            } else {
                System.out.println(message.getMessage());
            }
        }
    }

    private void sendBroadcastMessage(String message) {
        String sender = ChatManager.getUsers().get(this.socket).getLogin();

        for (Socket socket : ChatManager.getUsers().keySet()) {
            if (socket != this.socket) {
                PrintWriter writer = null;
                try {
                    writer = new PrintWriter(socket.getOutputStream(), true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writer.println("BCST [" + sender + "] " + message);
            }
        }
    }

    private void sendGroupMessage(Group group, String message) {
        String sender = ChatManager.getUsers().get(this.socket).getLogin();
        ;
        for (String member : group.getMembers()) {
            if (!member.equals(sender)) {
                Socket destination = ChatManager.findUserByLogin(member);
                PrintWriter writer = null;
                try {
                    writer = new PrintWriter(destination.getOutputStream(), true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writer.println("GROUP_MESSAGE [" + sender + "] " + message);
            }
        }

        if (!sender.equals(group.getAdmin())) {
            Socket destination = ChatManager.findUserByLogin(group.getAdmin());
            PrintWriter writer = null;
            try {
                writer = new PrintWriter(destination.getOutputStream(), true);
            } catch (IOException e) {

                e.printStackTrace();
            }
            writer.println("GROUP_MESSAGE [" + sender + "] " + message);
        }
    }
}
