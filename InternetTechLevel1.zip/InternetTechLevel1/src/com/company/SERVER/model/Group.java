package com.company.SERVER.model;

import java.util.ArrayList;
import java.util.List;

public class Group {
    private static int lastAssignedId;
    private int groupId;

    private List<String> members;

    private List<String> banned;

    private String admin;

    private String groupName;

    public Group(String admin, String groupName) {
        lastAssignedId++;

        this.groupId = lastAssignedId;
        this.members = new ArrayList<>();
        this.banned = new ArrayList<>();
        this.admin = admin;
        this.groupName = groupName;
    }

    public int getGroupId() {
        return groupId;
    }

    public List<String> getMembers() {
        return members;
    }

    public String getAdmin() {
        return admin;
    }

    public String getGroupName() {
        return groupName;
    }

    public List<String> getBanned() {
        return banned;
    }

    public void addMember(String newMember) {
        this.members.add(newMember);
    }

    public void kickMember(String member) {
        this.removeMember(member);
        this.banned.add(member);
    }


    public void removeMember(String userLogin) {
        this.members.remove(userLogin);
    }

    @Override
    public String toString() {
        return "Group{" +
                "groupId=" + groupId +
                ", members=" + members +
                ", banned=" + banned +
                ", admin='" + admin + '\'' +
                ", groupName='" + groupName + '\'' +
                '}';
    }
}
