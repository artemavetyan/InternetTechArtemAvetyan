package com.company.CLIENT.listeners;

import com.company.CLIENT.messages.ClientSideMessage;
import com.company.CLIENT.messages.ClientSideMessageInterpreter;

import java.io.*;
import java.net.Socket;

public class ServerListener implements Runnable {

    private BufferedReader reader;
    private Socket socket;
    private ClientSideMessageInterpreter interpreter;

    public ServerListener(Socket socket, ClientSideMessageInterpreter interpreter) {
        this.socket = socket;
        try {
            this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.interpreter = interpreter;
    }

    @Override
    public void run() {
        String line = "";
        while (!this.socket.isClosed()) {
            try {
                line = reader.readLine();
                ClientSideMessage message = new ClientSideMessage(line, ClientSideMessage.Sender.SERVER);
                interpreter.interprete(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
