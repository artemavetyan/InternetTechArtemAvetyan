package com.company.SERVER;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Set;

public class PingPong implements Runnable {

    @Override
    public void run() {
        while (!ChatManager.getUsers().isEmpty()) {
            Set<Socket> users = ChatManager.getUsers().keySet();

            for (Socket socket : users) {
                PrintWriter writer = null;
                try {
                    writer = new PrintWriter(socket.getOutputStream(), true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writer.println("PING");

                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
