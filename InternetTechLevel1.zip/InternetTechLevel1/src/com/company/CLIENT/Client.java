package com.company.CLIENT;

import com.company.CLIENT.listeners.UserListener;
import com.company.CLIENT.listeners.ServerListener;
import com.company.CLIENT.messages.ClientSideMessageInterpreter;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public void run() {
        // Set up a connection with the server.
        // If you are connecting locally use SERVER_ADDRESS = “127.0.0.1”.
        Socket socket = null;
        try {
            socket = new Socket("127.0.0.1", 1337);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Scanner scanner = new Scanner(System.in);

        ClientSideMessageInterpreter interpreter = new ClientSideMessageInterpreter(socket);

        UserListener userListener = new UserListener(socket, scanner, interpreter);
        ServerListener serverListener = new ServerListener(socket, interpreter);

        Thread cl = new Thread(userListener);
        Thread sl = new Thread(serverListener);

        cl.start();

        sl.start();
    }
}
