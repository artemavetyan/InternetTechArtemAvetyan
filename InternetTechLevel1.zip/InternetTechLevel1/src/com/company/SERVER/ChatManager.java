package com.company.SERVER;

import com.company.SERVER.model.Group;
import com.company.SERVER.model.User;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatManager {

    private static List<Group> groups;
    private static Map<Socket, User> users;

    public ChatManager() {
        groups = new ArrayList<>();
        users = new HashMap<>();
    }

    public static void addUser(String login, Socket socket) {
//        users.add(new User(login, socket));
        users.put(socket, new User(login));
        System.out.println(users.values());
    }

    public static void addUser(Socket socket) {
        users.put(socket, null);
    }

    public static void addGroup(String admin, String groupName) {
        groups.add(new Group(admin, groupName));
        System.out.println(groups);
    }

    public static List<Group> getGroups() {
        return groups;
    }
//
//    public static List<User> getUsers() {
//        return users;
//    }


    public static Map<Socket, User> getUsers() {
        return users;
    }

    public static boolean isUniqueLogin(String login) {
        for (User user : users.values()) {
            if (user != null && user.getLogin().equals(login)) {
                return false;
            }
        }
        return true;
    }

    public static boolean isValidLogin(String message) {
        String regex = "[a-zA-Z0-9_]+";
        return message.matches(regex);
    }

    public static void deleteUser(Socket socket) {
        users.remove(socket);
    }

    public static Socket findUserByLogin(String destinationLogin) {
        for (Socket socket : users.keySet()) {
            if (users.get(socket) != null && users.get(socket).getLogin().equals(destinationLogin)) {
                return socket;
            }
        }
        return null;
    }

    public static String retrieveMessageFromPrivateMessage(String message) {
        return message.replaceAll("^@[a-zA-Z0-9_]+\\s+", "");
    }

    public static String retrieveLoginFromPrivateMessage(String message) {
        int start = message.indexOf('@');
        int end = message.indexOf(' ');
        return message.substring(start + 1, end);
    }

    public static String retrieveMessageFromGroupMessage(String message) {
        return message.replaceAll("^@@.+\\s+", "");
    }

    public static String retrieveGroupNameFromMessage(String message) {
        int start = message.lastIndexOf('@');
        int end = message.indexOf(' ');
        return message.substring(start + 1, end);
    }

    public static Group findGroupByName(String groupName) {
        for (Group group : groups) {
            if (group.getGroupName().equals(groupName)) {
                return group;
            }
        }
        return null;
    }

    public static String retrieveGroupNameFromKickMessage(String message) {
        int end = message.indexOf(" ");
        return message.substring(0, end);
    }
}
