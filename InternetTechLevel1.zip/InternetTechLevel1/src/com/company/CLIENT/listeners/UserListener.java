package com.company.CLIENT.listeners;

import com.company.CLIENT.messages.ClientSideMessage;
import com.company.CLIENT.messages.ClientSideMessageInterpreter;

import java.net.Socket;
import java.util.Scanner;

public class UserListener implements Runnable {

    private Scanner scanner;
    private ClientSideMessageInterpreter interpreter;
    private Socket socket;

    public UserListener(Socket socket, Scanner scanner, ClientSideMessageInterpreter interpreter) {
        this.scanner = scanner;
        this.interpreter = interpreter;
        this.socket = socket;
    }

    @Override
    public void run() {

        String userInput = "";

        while (!this.socket.isClosed()) {
            userInput = scanner.nextLine();

            ClientSideMessage message = new ClientSideMessage(userInput, ClientSideMessage.Sender.CLIENT);
            interpreter.interprete(message);
        }
    }
}
