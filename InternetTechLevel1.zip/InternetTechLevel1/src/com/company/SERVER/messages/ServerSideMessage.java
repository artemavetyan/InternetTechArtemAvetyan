package com.company.SERVER.messages;

public class ServerSideMessage {

    enum Type {
        LOGIN,
        QUIT,
        BROADCAST,
        GET_USERS,
        PM,
        PONG,
        CREATE_GROUP,
        GET_GROUPS,
        JOIN_GROUP,
        GROUP_MESSAGE,
        LEAVE_GROUP,
        KICK
    }

    private String message;
    private Type type;

    public ServerSideMessage(String message) {
        init(message);
    }

    private void init(String line) {
        if (line.startsWith("HELO")) {
            this.type = Type.LOGIN;
            this.message = line.replaceAll("HELO ", "");
        } else if (line.startsWith("BCST")) {
            this.type = Type.BROADCAST;
            this.message = line.replaceAll("BCST ", "");
        } else if (line.equals("QUIT")) {
            this.type = Type.QUIT;
            this.message = "+OK Goodbye";
        } else if (line.startsWith("GET_USERS")) {
            this.type = Type.GET_USERS;
            this.message = "";
        } else if (line.startsWith("PM")) {
            this.type = Type.PM;
            this.message = line.replace("PM ", "");
        } else if (line.startsWith("CREATE_GROUP")) {
            this.type = Type.CREATE_GROUP;
            this.message = line.replace("CREATE_GROUP ", "");
        } else if (line.startsWith("GET_GROUPS")) {
            this.type = Type.GET_GROUPS;
            this.message = "";
        } else if (line.startsWith("JOIN_GROUP")) {
            this.type = Type.JOIN_GROUP;
            this.message = line.replace("JOIN_GROUP ", "");
        } else if (line.startsWith("GROUP_MESSAGE")) {
            this.type = Type.GROUP_MESSAGE;
            this.message = line.replace("GROUP_MESSAGE ", "");
        } else if (line.startsWith("LEAVE_GROUP")) {
            this.type = Type.LEAVE_GROUP;
            this.message = line.replace("LEAVE_GROUP ", "");
        } else if (line.startsWith("KICK")) {
            this.type = Type.KICK;
            this.message = line.replace("KICK ", "");
        } else if (line.equals("PONG")) {
            this.type = Type.PONG;
            this.message = "PONG ";
        }
    }

    public String getMessage() {
        return message;
    }

    public Type getType() {
        return type;
    }
}
