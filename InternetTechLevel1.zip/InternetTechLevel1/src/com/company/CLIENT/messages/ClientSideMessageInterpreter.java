package com.company.CLIENT.messages;

import com.company.tools.Printer;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientSideMessageInterpreter {

    private PrintWriter writer;
    private Socket socket;

    private enum State {
        CREATED,
        CONNECTED,
        LOGGED_IN,
        DISCONNECTED
    }

    private State state;

    public ClientSideMessageInterpreter(Socket socket) {
        try {
            this.writer = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.socket = socket;
        this.state = State.CREATED;

    }

    public void interprete(ClientSideMessage message) {
        if (message.getSender() == ClientSideMessage.Sender.SERVER) {
            if (message.getType() == ClientSideMessage.Type.PING) {
                writer.println(message.getMessage());
            } else if (message.getType() == ClientSideMessage.Type.LOGIN) {
                Printer.printOkMessage(message.getMessage());
                this.state = State.CONNECTED;
            } else if (message.getType() == ClientSideMessage.Type.CRITICAL_ERROR) {
                System.out.println("ERROR");
                Printer.printError(message.getMessage());
                try {
                    this.socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (message.getType() == ClientSideMessage.Type.OTHERS_BROADCAST) {
                Printer.printOthersMessage(message.getMessage());
            } else if (message.getType() == ClientSideMessage.Type.HELO) {
                Printer.printOkMessage(message.getMessage());
                this.state = State.LOGGED_IN;
            } else if (message.getType() == ClientSideMessage.Type.QUIT) {
                Printer.printOkMessage(message.getMessage());
                this.state = State.DISCONNECTED;
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (message.getType() == ClientSideMessage.Type.PM) {
                Printer.printOthersMessage(message.getMessage());
            } else if (message.getType() == ClientSideMessage.Type.SOFT_ERROR) {
                Printer.printError(message.getMessage());
            } else if (message.getType() == ClientSideMessage.Type.GROUP_MESSAGE) {
                Printer.printGroupMessage(message.getMessage());
            } else if (message.getType() == ClientSideMessage.Type.SUCCESS) {
                Printer.printOkMessage(message.getMessage());
            }

        } else {
            System.out.println(message.getType());
            System.out.println(state);
            if (state == State.CONNECTED) {
                if (message.getType() == ClientSideMessage.Type.MESSAGE) {
                    writer.println("HELO " + message.getMessage());
                } else if (message.getType() == ClientSideMessage.Type.QUIT) {
                    writer.println(message.getMessage());
                } else {
                    System.out.println("You are not authorised to write this message!");
                }
            } else if (this.state == State.LOGGED_IN) {
                if (message.getType() == ClientSideMessage.Type.MESSAGE) {
                    writer.println("BCST " + message.getMessage());
                } else {
                    writer.println(message.getMessage());
                }
            } else {
                System.out.println("You are not authorised to write this message!");
            }
        }
    }
}
